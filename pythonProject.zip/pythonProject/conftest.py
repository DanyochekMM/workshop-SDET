import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options


@pytest.fixture(scope="module")
def driver():
    options = Options()
    options.add_experimental_option("detach", True)
    service = Service(r"C:\Windows\yandexdriver.exe")
    driver = webdriver.Chrome(service=service, options=options)
    yield driver
    # driver.quit()
