import pytest
from pages.registration_page import RegistPage
# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
# from selenium.webdriver.chrome.options import Options
# from selenium.webdriver.common.keys import Keys
# import time
# from selenium.webdriver.support.select import Select


class TestRegistPage:
    # @pytest.mark.parametrize()
    def test_login(self, driver):
        registration_page = RegistPage(driver)
        driver.get("https://demoqa.com/automation-practice-form")

        registration_page.enter_firstname("Goga")
        registration_page.enter_lastname("Tupur")
        registration_page.enter_email("gogich.@mail.com")
        registration_page.enter_gender("Male")
        registration_page.enter_number("2222222222")
        registration_page.enter_date({"day": "12", "month": "September", "year": "2004"})
        registration_page.enter_subjects("Maths")
        registration_page.enter_hobbies(["Sports", "Music"])
        registration_page.enter_picture(r"C:\Users\pro15\Pictures\Screenshots\Снимок экрана 2023-12-12 161542.png")
        registration_page.enter_address("dsjnfjdnfdjnf")
        registration_page.enter_state_city("NCR", "Noida")

        registration_page.click_button_submit()

        assert driver.find_element(By.ID, "example-modal-sizes-title-lg").text == "Thanks for submitting the form"
