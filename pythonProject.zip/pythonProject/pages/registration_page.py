# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
# from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.support.select import Select
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC


class RegistPage:
    def __init__(self, driver):
        self.driver = driver

    def enter_firstname(self, firstname):
        firstname_field = self.driver.find_element(By.ID, "firstName")
        firstname_field.send_keys(firstname)

    def enter_lastname(self, lastname):
        lastname_field = self.driver.find_element(By.ID, "lastName")
        lastname_field.send_keys(lastname)

    def enter_email(self, email):
        email_field = self.driver.find_element(By.ID, "userEmail")
        email_field.send_keys(email)

    def enter_number(self, mobile):
        email_field = self.driver.find_element(By.ID, "userNumber")
        email_field.send_keys(mobile)

    def enter_gender(self, gender):
        if gender == "Male":
            gender_radio = self.driver.find_element(By.CSS_SELECTOR, "#gender-radio-1")
            self.driver.execute_script("arguments[0].click();", gender_radio)
        elif gender == "Female":
            gender_radio = self.driver.find_element(By.CSS_SELECTOR, "#gender-radio-2")
            self.driver.execute_script("arguments[0].click();", gender_radio)
        elif gender == "Other":
            gender_radio = self.driver.find_element(By.CSS_SELECTOR, "#gender-radio-2")
            self.driver.execute_script("arguments[0].click();", gender_radio)

    def enter_date(self, date):
        time.sleep(2)
        self.driver.find_element(By.ID, "dateOfBirthInput").click()

        month = self.driver.find_element(By.CLASS_NAME, "react-datepicker__month-select")
        select_month = Select(month)
        select_month.select_by_visible_text(date["month"])

        year = self.driver.find_element(By.CLASS_NAME, "react-datepicker__year-select")
        select_year = Select(year)
        select_year.select_by_visible_text(date["year"])

        self.driver.find_element(By.XPATH, f"//div[contains(@class, 'react-datepicker__day') and text()='{date["day"]}']").click()

    def enter_subjects(self, subjects):
        subjects_field = self.driver.find_element(By.ID, "subjectsInput")
        subjects_field.send_keys(subjects)
        subjects_field.send_keys(Keys.ENTER)

    def enter_picture(self, picture):
        picture_field = self.driver.find_element(By.ID, "uploadPicture")
        picture_field.send_keys(picture)

    def enter_address(self, address):
        address_field = self.driver.find_element(By.ID, "currentAddress")
        address_field.send_keys(address)

    def enter_hobbies(self, hobbies):
        if hobbies:
            for hobby in hobbies:
                if hobby == "Sports":
                    hobby_1 = self.driver.find_element(By.XPATH, '//*[@id="hobbies-checkbox-1"]')
                    self.driver.execute_script("arguments[0].click();", hobby_1)

                if hobby == "Reading":
                    hobby_2 = self.driver.find_element(By.XPATH, '//*[@id="hobbies-checkbox-2"]')
                    self.driver.execute_script("arguments[0].click();", hobby_2)

                if hobby == "Music":
                    hobby_3 = self.driver.find_element(By.XPATH, '//*[@id="hobbies-checkbox-3"]')
                    self.driver.execute_script("arguments[0].click();", hobby_3)

    def enter_state_city(self, state, city):
        state_input = self.driver.find_element(By.ID, "react-select-3-input")
        state_input.send_keys(state)
        state_input.send_keys(Keys.ENTER)

        city_input = self.driver.find_element(By.ID, "react-select-4-input")
        city_input.send_keys(city)
        city_input.send_keys(Keys.ENTER)

    def click_button_submit(self):
        self.driver.find_element(By.ID, "submit").click()
